# Notes_taking_website
you can keep records of your notes here
