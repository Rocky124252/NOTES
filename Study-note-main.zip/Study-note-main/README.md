# This is a project for writing notes

**Author** -> Worthy Programmer


**Status** -> Unfinished
